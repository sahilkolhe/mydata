create table product(id int primary key auto_increment, title varchar(50), description varchar(50), price float);
create table category(id int primary key auto_increment, title varchar(50), description varchar(50));
create table user(id int primary key auto_increment, name  varchar(50), email varchar(50), phone varchar(50));